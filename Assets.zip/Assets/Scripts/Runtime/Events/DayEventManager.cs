
using ProjectED.Cases;
using ProjectED.Days;
using ProjectED.Examination;
using UnityEngine;

public class DayEventManager : MonoBehaviour
{
    [Header("?��?�� NPC ?��?��?��")]
    [SerializeField] private CitizenCaseData merchantCase;
    [SerializeField] private CitizenCaseData addictCase;

    public CitizenCaseData ActiveMerchantCase { get; private set; }
    public CitizenCaseData AddictCase => addictCase;

    // ?��?�� CampaignManager?��?�� ?��?�� ?���? ???기열?�� ?��?�� ?�� 참조?��?��.
    public bool ShouldScheduleAddict(int day)
    {
        if (addictCase == null || GameManager.Instance == null) return false;
        if (day == 5) return true;
        return GameManager.Instance.CanAddictReturn(day);
    }

    [Header("?��?�� DAY ?��벤트")]
    public int activeDay;
    public bool merchantOfferPending;
    public bool addictTriggeredToday;
    public bool day6AngerTriggered;

    [Header("?��?�� ?��벤트 기록")]
    public int addictEncounterCount;

    private ExaminationController examinationController;
    private int totalCitizens;
    private bool merchantTriggeredToday;

    public void Bind(ExaminationController controller)
    {
        if (examinationController == controller)
            return;

        if (examinationController != null)
        {
            examinationController.CitizenJudged -= OnCitizenJudged;
        }

        examinationController = controller;

        if (examinationController != null)
        {
            examinationController.CitizenJudged += OnCitizenJudged;
        }
    }

    private void OnDestroy()
    {
        if (examinationController != null)
        {
            examinationController.CitizenJudged -= OnCitizenJudged;
        }
    }

    public void BeginDay(int day, int citizenCount)
    {
        if (activeDay == day && totalCitizens == citizenCount)
            return;
        activeDay = day;
        totalCitizens = citizenCount;

        merchantTriggeredToday = false;
        merchantOfferPending = false;
        addictTriggeredToday = false;
        day6AngerTriggered = false;
        ActiveMerchantCase = null;

        Debug.Log("DAY " + day + " ?��벤트 �?�? ?���?");
    }

    private void OnCitizenJudged(
        CitizenCaseInstance citizen,
        CaseDisposition disposition,
        bool isCorrect)
    {
        if (examinationController == null)
            return;

        int position = examinationController.CurrentCitizenPosition;

        int middlePosition = Mathf.Max(
            1,
            Mathf.CeilToInt(totalCitizens / 2f)
        );

        // ?��?�� ?��벤트
        if (!merchantTriggeredToday &&
            GameManager.Instance != null &&
            GameManager.Instance.merchantPresentToday &&
            position == middlePosition)
        {
            merchantTriggeredToday = true;
            merchantOfferPending = true;
            ActiveMerchantCase = merchantCase;

            Debug.Log("?��?�� 그림 구매 ?��?�� 발생");
        }

        // DAY 5-12 중독?�� ?���? ?���?
        if (activeDay >= 5 && activeDay <= 12 &&
            !addictTriggeredToday &&
            addictCase != null &&
            citizen != null &&
            citizen.SourceCase == addictCase)
        {
            addictTriggeredToday = true;
            addictEncounterCount++;

            if (GameManager.Instance != null)
            {
                GameManager.Instance.RecordAddictResult(activeDay, disposition.ToString());
            }

            Debug.Log("중독?�� ?��?�� ?���?");
            Debug.Log("중독?�� 처리: " + disposition);
        }

        // DAY 6 마�??�? ?���? 반려
        if (activeDay == 6 &&
            !day6AngerTriggered &&
            position == totalCitizens &&
            disposition == CaseDisposition.DocumentRejection)
        {
            day6AngerTriggered = true;
            Debug.Log("DAY 6 마�??�? ?���? 진상 ?��벤트");
        }
    }

    [ContextMenu("?��?�� ?��?�� ?��?��")]
    public void AcceptMerchantOffer()
    {
        if (!merchantOfferPending)
            return;

        bool success =
            GameManager.Instance != null &&
            GameManager.Instance.TryBuyMerchantPainting();

        merchantOfferPending = false;

        Debug.Log(success
            ? "그림 ?��?�� ?���?"
            : "그림 ?��?�� ?��?��");
    }

    [ContextMenu("?��?�� ?��?�� 거절")]
    public void RejectMerchantOffer()
    {
        if (!merchantOfferPending)
            return;

        merchantOfferPending = false;
        Debug.Log("?��?�� ?��?�� 거절");
    }
}
