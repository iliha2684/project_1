using System;
using System.Collections.Generic;
using ProjectED.Cases;

namespace ProjectED.Days
{
    public readonly struct CitizenGenerationIssue
    {
        public CitizenGenerationIssue(CaseValidationSeverity severity, string message)
        {
            Severity = severity;
            Message = message;
        }

        public CaseValidationSeverity Severity { get; }
        public string Message { get; }
    }

    public sealed class CitizenGenerationResult
    {
        internal CitizenGenerationResult(CitizenCaseInstance citizen, List<CitizenGenerationIssue> issues)
        {
            Citizen = citizen;
            Issues = issues;
        }

        public CitizenCaseInstance Citizen { get; }
        public IReadOnlyList<CitizenGenerationIssue> Issues { get; }

        public bool Success
        {
            get
            {
                if (Citizen == null)
                {
                    return false;
                }

                foreach (var issue in Issues)
                {
                    if (issue.Severity == CaseValidationSeverity.Error)
                    {
                        return false;
                    }
                }

                return true;
            }
        }
    }

    public sealed class GeneralCitizenGenerator
    {
        public CitizenGenerationResult Generate(DayDefinition day, int daySeed, int sequenceIndex)
        {
            if (day == null)
            {
                return Failed("?���? ?��민을 ?��?��?�� DayDefinition?�� ?��?��?��?��.");
            }

            var citizenSeed = CombineSeed(daySeed, day.DayNumber, sequenceIndex);
            return Generate(day, new Random(citizenSeed), sequenceIndex);
        }

        public CitizenGenerationResult Generate(DayDefinition day, Random random, int sequenceIndex)
        {
            if (day == null)
            {
                return Failed("?���? ?��민을 ?��?��?�� DayDefinition?�� ?��?��?��?��.");
            }

            if (random == null)
            {
                return Failed("?���? ?���? ?��?��?�� ?��?��기�?? ?��?��?��?��.");
            }

            if (sequenceIndex < 1)
            {
                return Failed("?���? ?���? ?��번�?? 1 ?��?��?��?��?�� ?��?��?��.");
            }

            var issues = new List<CitizenGenerationIssue>();
            var dayId = string.IsNullOrWhiteSpace(day.DayId) ? $"DAY_{day.DayNumber:00}" : day.DayId.Trim();
            var citizen = new CitizenCaseInstance(
                $"{dayId}_GENERAL_{sequenceIndex:00}",
                dayId,
                sequenceIndex);

            AddBaseTags(citizen, day);

            for (var index = 0; index < day.ActiveConditionPools.Count; index++)
            {
                var pool = day.ActiveConditionPools[index];
                if (pool == null)
                {
                    issues.Add(new CitizenGenerationIssue(
                        CaseValidationSeverity.Error,
                        $"?��?�� 조건 ??? {index + 1}번이 비어 ?��?��?��?��."));
                    continue;
                }

                var missingFeatures = pool.RequiredFeatures & ~day.UnlockedFeatures;
                if (missingFeatures != DayFeatureFlags.None)
                {
                    issues.Add(new CitizenGenerationIssue(
                        CaseValidationSeverity.Error,
                        $"조건 ??? '{GetPoolName(pool)}'?�� ?��?��?�� 기능?�� ?��금되�? ?��?��?��?��?��: {missingFeatures}"));
                    continue;
                }

                if (!pool.TryChooseCompatible(random, citizen.TagSet, out var option))
                {
                    if (pool.RequiredForEveryCitizen)
                    {
                        issues.Add(new CitizenGenerationIssue(
                            CaseValidationSeverity.Error,
                            $"?��?�� 조건 ??? '{GetPoolName(pool)}'?��?�� ?��?�� ?��그�?? ?��?��?��?�� ?��?���?�? 찾�?? 못했?��?��?��."));
                    }
                    else
                    {
                        issues.Add(new CitizenGenerationIssue(
                            CaseValidationSeverity.Info,
                            $"?��?�� 조건 ??? '{GetPoolName(pool)}'??? ?��?��?��?�� ?��?���?�? ?��?�� 건너?��?��?��?��?��."));
                    }

                    continue;
                }

                ApplyOption(citizen, pool, option, issues);
            }

            ValidateGeneratedCitizen(citizen, day, issues);
            ValidateDailyRegulations(citizen, day, issues);
            return new CitizenGenerationResult(citizen, issues);
        }

        private static void ApplyOption(
            CitizenCaseInstance citizen,
            CitizenConditionPoolData pool,
            CitizenConditionOption option,
            ICollection<CitizenGenerationIssue> issues)
        {
            citizen.RecordSelection(pool, option);
            citizen.AddTag($"pool:{pool.PoolId}");
            citizen.AddTag($"option:{option.OptionId}");

            foreach (var assignment in option.Values)
            {
                if (assignment == null)
                {
                    issues.Add(new CitizenGenerationIssue(
                        CaseValidationSeverity.Error,
                        $"조건 '{GetOptionName(option)}'?�� 비어 ?��?�� ?��?�� 값이 ?��?��?��?��."));
                    continue;
                }

                if (!assignment.TryResolveValue(citizen, out var resolvedValue, out var resolveError))
                {
                    issues.Add(new CitizenGenerationIssue(
                        CaseValidationSeverity.Error,
                        $"조건 '{GetOptionName(option)}': {resolveError}"));
                    continue;
                }

                if (citizen.SetValue(assignment.Field, resolvedValue))
                {
                    issues.Add(new CitizenGenerationIssue(
                        CaseValidationSeverity.Warning,
                        $"?��?�� '{assignment.Field}'�? ?���? 조건 '{GetOptionName(option)}'?�� 값으�? ?��?��?��졌습?��?��."));
                }
            }

            foreach (var tag in option.ProvidedTags)
            {
                citizen.AddTag(tag);
            }
        }

        private static void ValidateGeneratedCitizen(
            CitizenCaseInstance citizen,
            DayDefinition day,
            ICollection<CitizenGenerationIssue> issues)
        {
            if (string.IsNullOrWhiteSpace(citizen.DisplayName))
            {
                issues.Add(new CitizenGenerationIssue(
                    CaseValidationSeverity.Warning,
                    "?��?��?�� ?��민의 ?��?�� ?��름이 ?��?��?��?��. Identity 조건 ????��?�� DisplayName?�� �??��?��?�� 것을 권장?��?��?��."));
            }

            if (day.HasFeature(DayFeatureFlags.CitizenIdCard) &&
                !citizen.HasValue(GeneratedCitizenField.IdCardSubmitted))
            {
                issues.Add(new CitizenGenerationIssue(
                    CaseValidationSeverity.Info,
                    "?��민증 기능?�� ?��금되?���?�? IdCardSubmitted 값이 ?��?��?���? ?��?��?��?��?��."));
            }
        }

        private static void AddBaseTags(CitizenCaseInstance citizen, DayDefinition day)
        {
            citizen.AddTag("citizen:general");
            citizen.AddTag($"day:{day.DayNumber}");

            foreach (DayFeatureFlags feature in Enum.GetValues(typeof(DayFeatureFlags)))
            {
                if (feature != DayFeatureFlags.None && day.HasFeature(feature))
                {
                    citizen.AddTag($"feature:{feature}");
                }
            }
        }

        private static void ValidateDailyRegulations(
            CitizenCaseInstance citizen,
            DayDefinition day,
            ICollection<CitizenGenerationIssue> issues)
        {
            foreach (var regulation in day.ActiveRegulations)
            {
                if (regulation == null)
                {
                    continue;
                }

                var result = regulation.Evaluate(citizen);
                if (result.Status == RegulationEvaluationStatus.MissingData)
                {
                    issues.Add(new CitizenGenerationIssue(
                        CaseValidationSeverity.Error,
                        $"규정 '{GetRegulationName(regulation)}'?�� ?��?��?�� ?�� ?��?��?��?��. {result.Message}"));
                }
                else if (result.Status == RegulationEvaluationStatus.Violated)
                {
                    issues.Add(new CitizenGenerationIssue(
                        CaseValidationSeverity.Error,
                        $"?��?�� ?���? ?��민이 규정 '{GetRegulationName(regulation)}'?�� ?��반했?��?��?��. {result.Message}"));
                }
            }
        }

        private static int CombineSeed(int daySeed, int dayNumber, int sequenceIndex)
        {
            unchecked
            {
                var seed = daySeed;
                seed = (seed * 397) ^ dayNumber;
                seed = (seed * 397) ^ sequenceIndex;
                return seed;
            }
        }

        private static CitizenGenerationResult Failed(string message)
        {
            return new CitizenGenerationResult(
                null,
                new List<CitizenGenerationIssue>
                {
                    new(CaseValidationSeverity.Error, message)
                });
        }

        private static string GetPoolName(CitizenConditionPoolData pool)
        {
            return string.IsNullOrWhiteSpace(pool.DisplayName) ? pool.name : pool.DisplayName;
        }

        private static string GetOptionName(CitizenConditionOption option)
        {
            return string.IsNullOrWhiteSpace(option.DisplayName) ? option.OptionId : option.DisplayName;
        }

        private static string GetRegulationName(DayRegulationData regulation)
        {
            return string.IsNullOrWhiteSpace(regulation.DisplayName)
                ? regulation.RegulationId
                : regulation.DisplayName;
        }
    }

}
